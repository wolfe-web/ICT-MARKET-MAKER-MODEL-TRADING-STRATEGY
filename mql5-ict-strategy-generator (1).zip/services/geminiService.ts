import { GoogleGenAI } from "@google/genai";

interface Mql5Inputs {
  lotSize: string;
  takeProfitOption: string;
}

const getTpModeDefault = (option: string): string => {
    const map: { [key: string]: string } = {
        'PDH/PDL': 'TP_PDH_PDL',
        'RR_1_1': 'TP_RR_1_1',
        'RR_1_1_5': 'TP_RR_1_1_5',
        'RR_1_2': 'TP_RR_1_2',
        'RR_1_3': 'TP_RR_1_3',
    };
    return map[option] || 'TP_PDH_PDL';
};

const createPrompt = (inputs: Mql5Inputs) => {
  const tpModeDefault = getTpModeDefault(inputs.takeProfitOption);
  return `
Act as an expert MQL5 programmer. Your task is to write a complete, robust, and well-commented MQL5 expert advisor (EA).

**Strategy Name:** London Session ICT Liquidity Sweep with CISD Entry

**Core Logic:**
The EA should monitor price action during the London trading session. It looks for a liquidity sweep of the Asian session range, followed by a "Change in State of Delivery" (CISD) as confirmation, and then seeks an entry on a high-probability Fair Value Gap (FVG).

**Key Timeframes & Sessions:**
- Asian Session: 20:00 - 00:00 New York Time (GMT-4 / GMT-5 depending on DST). The code should allow user to configure offsets based on server time.
- London Session: 02:00 - 05:00 New York Time. This is the "London Killzone" where the EA should be active for new setups.

**User-Configurable Inputs (EA Inputs):**
Make sure the following are included as 'input' variables in the MQL5 code with the specified default values:
- LotSize: The lot size for trades. Default value: ${inputs.lotSize}
- RiskPercentage: Risk percentage of account balance for stop loss calculation (if LotSize is 0). Default value: 1.0
- AsianSession_Start_Hour: Server hour for Asian session start. Default value: 1
- AsianSession_End_Hour: Server hour for Asian session end. Default value: 5
- LondonSession_Start_Hour: Server hour for London killzone start. Default value: 9
- LondonSession_End_Hour: Server hour for London killzone end. Default value: 12
- FVG_Lookback_Candles: Number of candles to look back for an FVG. Default value: 20
- TakeProfit_Mode: An enum to select the Take Profit calculation method. Default value: ${tpModeDefault}
- TrailToBreakEven: Enable/disable trailing stop to break-even. (true/false) Default value: true
- BreakEvenRR: The risk-to-reward ratio to trigger moving SL to BE (e.g., 1.0 for 1:1 RR). Default value: 1.0

---

**Bullish Scenario:**

1.  **Identify Asian Range:** At the start of the London session, identify the high and low of the preceding Asian session.
2.  **Liquidity Sweep:** During the London session, wait for the price to trade *below* the Asian session low.
3.  **Change in State of Delivery (CISD):** After sweeping the Asian low, watch for a bullish CISD. A CISD is confirmed when the price rallies and a candle **closes above a recent, significant bearish Fair Value Gap (FVG)**. This now-reclaimed bearish FVG is considered an "Inversion FVG" and is expected to act as support.
4.  **Identify Entry Point:** After the CISD is confirmed, the EA should identify potential entry points. There are two valid entry types:
    *   **Type A (Inversion FVG):** The Inversion FVG that was just broken through.
    *   **Type B (New FVG):** Any new bullish FVG that formed during the price rally that caused the CISD.
    *   A Bullish FVG is a three-candle pattern where the high of the first candle is lower than the low of the third candle.
5.  **Entry:** Place a market BUY order when price retraces into the first available entry point, whether it's the Inversion FVG (Type A) or a new Bullish FVG (Type B).
6.  **Stop Loss:** The Stop Loss placement depends on the FVG used for entry:
    *   If entry was in the Inversion FVG, place the SL at the low of that Inversion FVG's formation, plus a small, non-configurable buffer for spread/slippage (e.g., 2 pips worth of points).
    *   If entry was in a new Bullish FVG, place the SL at the low of that new FVG's formation (candle 2), plus the buffer.
7.  **Take Profit:** The Take Profit level depends on the 'TakeProfit_Mode' input:
    *   If 'TP_PDH_PDL', target the Previous Day's High (PDH).
    *   If 'TP_RR_1_1' to 'TP_RR_1_3', calculate TP based on a risk-to-reward ratio from 1:1 to 1:3.

---

**Bearish Scenario:**

1.  **Identify Asian Range:** At the start of the London session, identify the high and low of the preceding Asian session.
2.  **Liquidity Sweep:** During the London session, wait for the price to trade *above* the Asian session high.
3.  **Change in State of Delivery (CISD):** After sweeping the Asian high, watch for a bearish CISD. A CISD is confirmed when the price falls and a candle **closes below a recent, significant bullish Fair Value Gap (FVG)**. This now-reclaimed bullish FVG is considered an "Inversion FVG" and is expected to act as resistance.
4.  **Identify Entry Point:** After the CISD is confirmed, identify potential entry points:
    *   **Type A (Inversion FVG):** The Inversion FVG that was just broken through.
    *   **Type B (New FVG):** Any new bearish FVG that formed during the price drop that caused the CISD.
    *   A Bearish FVG is a three-candle pattern where the low of the first candle is higher than the high of the third candle.
5.  **Entry:** Place a market SELL order when price retraces into the first available entry point, whether it's the Inversion FVG (Type A) or a new Bearish FVG (Type B).
6.  **Stop Loss:** The Stop Loss placement depends on the FVG used for entry:
    *   If entry was in the Inversion FVG, place the SL at the high of that Inversion FVG's formation, plus a small buffer.
    *   If entry was in a new Bearish FVG, place the SL at the high of that new FVG's formation (candle 2), plus the buffer.
7.  **Take Profit:** The Take Profit level depends on the 'TakeProfit_Mode' input:
    *   If 'TP_PDH_PDL', target the Previous Day's Low (PDL).
    *   If 'TP_RR_1_1' to 'TP_RR_1_3', calculate TP based on a risk-to-reward ratio from 1:1 to 1:3.

---

**Trade Management:**

- **Trailing Stop to Break-Even:** If the \`TrailToBreakEven\` input is set to true, when a trade's profit reaches the initial risk multiplied by the \`BreakEvenRR\` input, the Stop Loss should be moved to the entry price. This check must happen on every tick.

---

**Code Requirements & Object Management:**

- The code must be a single, complete MQL5 Expert Advisor file (.mq5).
- Define an 'ENUM_TP_MODE' for Take Profit modes.
- Use clear variable names and extensive comments.
- Include proper error handling for trade execution.
- Ensure the EA only places one trade at a time.
- The final output should be ONLY the MQL5 code. Do not wrap it in markdown or add explanatory text.

**Chart Objects:**
- The EA should draw the Asian Range and PDH/PDL on the chart.
- **FVG Drawing:** When a valid FVG (new, or an inversion FVG) is identified as a potential entry point, it **must** be drawn on the chart as a filled rectangle (\`OBJ_RECTANGLE\`).
    - **Bullish FVGs (New or Inversion):** Draw rectangles with a color like \`clrCornflowerBlue\`.
    - **Bearish FVGs (New or Inversion):** Draw rectangles with a color like \`clrHotPink\`.
    - These rectangle objects should be set to draw in the background.
- **Pending Trade Lines:** When a valid trade setup is identified (FVG found after sweep and CISD, but before entry), the EA MUST draw the calculated Stop Loss and Take Profit price levels on the chart as horizontal lines (Red for SL, Green for TP, dotted style).
- **Object Lifecycle:** All drawn objects (FVG rectangles, pending SL/TP lines) for a potential setup MUST be removed if the setup becomes invalid or after a trade is executed. It is critical to manage object lifecycles to avoid chart clutter. Use unique names for objects.
`;
}


export const generateMql5Code = async (inputs: Mql5Inputs): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set.");
  }
  
  const prompt = createPrompt(inputs);

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    // Clean the response text
    let code = response.text;
    
    // Remove markdown code block fences if they exist
    code = code.replace(/^```mql5\n/, '');
    code = code.replace(/^```mq5\n/, '');
    code = code.replace(/^```\n/, '');
    code = code.replace(/\n```$/, '');

    return code.trim();
  } catch (error) {
    console.error("Error generating MQL5 code:", error);
    throw new Error("Failed to generate code from Gemini API. Check console for details.");
  }
};
