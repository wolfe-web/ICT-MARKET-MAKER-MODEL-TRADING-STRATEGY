
import React, { useState, useEffect } from 'react';
import { ClipboardIcon } from './icons/Icons';
import { CheckIcon } from './icons/Icons';

interface CodeDisplayProps {
  code: string;
  isLoading: boolean;
  error: string | null;
}

const CodeDisplay: React.FC<CodeDisplayProps> = ({ code, isLoading, error }) => {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (copied) {
      const timer = setTimeout(() => setCopied(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [copied]);

  const handleCopy = () => {
    if (code) {
      navigator.clipboard.writeText(code);
      setCopied(true);
    }
  };

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-gray-400">
           <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400 mb-4"></div>
           <p className="text-lg">Generating MQL5 code...</p>
           <p className="text-sm text-gray-500 mt-2">This may take a moment.</p>
        </div>
      );
    }

    if (error) {
      return (
        <div className="flex items-center justify-center h-full text-red-400 p-4">
          <div className="text-center">
            <p className="font-bold">An error occurred:</p>
            <p className="mt-2 text-sm">{error}</p>
          </div>
        </div>
      );
    }

    if (!code) {
      return (
        <div className="flex items-center justify-center h-full text-gray-500">
          <p>Your generated MQL5 code will appear here.</p>
        </div>
      );
    }

    return (
      <pre className="h-full overflow-auto p-4 text-sm text-gray-300">
        <code>{code}</code>
      </pre>
    );
  };
  
  return (
    <div className="bg-gray-800 rounded-xl border border-gray-700 shadow-2xl relative h-[80vh] min-h-[600px] flex flex-col">
       <div className="flex justify-between items-center p-3 bg-gray-900/50 rounded-t-xl border-b border-gray-700">
        <p className="text-sm font-semibold text-gray-400">Generated Expert Advisor (.mq5)</p>
        {code && !isLoading && !error && (
            <button
                onClick={handleCopy}
                className="flex items-center gap-2 text-xs bg-gray-700 hover:bg-gray-600 text-gray-300 font-semibold py-1 px-3 rounded-md transition-colors"
            >
                {copied ? <CheckIcon /> : <ClipboardIcon />}
                {copied ? 'Copied!' : 'Copy Code'}
            </button>
        )}
       </div>
      <div className="flex-grow relative">
        {renderContent()}
      </div>
    </div>
  );
};

export default CodeDisplay;
