
import React from 'react';

interface StrategyCardProps {
  title: string;
  icon: React.ReactNode;
  color: string;
  children: React.ReactNode;
}

const StrategyCard: React.FC<StrategyCardProps> = ({ title, icon, color, children }) => {
  return (
    <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-700 shadow-lg">
      <div className="flex items-center mb-4">
        <div className={`mr-4 ${color}`}>{icon}</div>
        <h3 className={`text-xl font-semibold ${color}`}>{title}</h3>
      </div>
      <div>{children}</div>
    </div>
  );
};

export default StrategyCard;
