import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import StrategyCard from './components/StrategyCard';
import CodeDisplay from './components/CodeDisplay';
import { generateMql5Code } from './services/geminiService';
import { BullishIcon, BearishIcon, SparklesIcon } from './components/icons/Icons';

interface StrategyInputs {
  lotSize: string;
  takeProfitOption: string;
}

const App: React.FC = () => {
  const [mql5Code, setMql5Code] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [inputs, setInputs] = useState<StrategyInputs>({
    lotSize: '0.01',
    takeProfitOption: 'PDH/PDL',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    if (value !== '' && parseFloat(value) < 0) return;
    setInputs(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target;
    setInputs(prev => ({ ...prev, [name]: value }));
  };

  const handleGenerateCode = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setMql5Code('');
    try {
      const payload = {
        lotSize: inputs.lotSize || '0.01',
        takeProfitOption: inputs.takeProfitOption || 'PDH/PDL',
      };
      const code = await generateMql5Code(payload);
      setMql5Code(code);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [inputs]);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 font-sans">
      <Header />
      <main className="container mx-auto p-4 md:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column: Strategy & Controls */}
          <div className="flex flex-col gap-8">
            <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-700 shadow-lg">
              <h2 className="text-2xl font-bold text-cyan-400 mb-3">The Strategy: London Liquidity Sweep (CISD Entry)</h2>
              <p className="text-gray-400">
                This Expert Advisor uses an advanced Inner Circle Trader (ICT) concept. It targets liquidity sweeps of the Asian session range during the London Killzone. After a confirmed Change in State of Delivery (CISD), it seeks entry on either a newly formed Fair Value Gap (FVG) or a reclaimed 'inversion' FVG.
              </p>
            </div>

            <StrategyCard
              title="Bullish Scenario"
              icon={<BullishIcon />}
              color="text-green-400"
            >
              <ul className="space-y-2 text-gray-400 list-disc list-inside">
                <li>Price sweeps below the Asian session low.</li>
                <li>A Change in State of Delivery (CISD) confirms the reversal (price closes above a prior bearish FVG).</li>
                <li>Enter BUY on a retest of the inverted bearish FVG or a newly created bullish FVG.</li>
                <li>Stop Loss is placed below the low of the entry FVG.</li>
                <li>Take Profit targets the Previous Day's High or a set R:R.</li>
              </ul>
            </StrategyCard>

            <StrategyCard
              title="Bearish Scenario"
              icon={<BearishIcon />}
              color="text-red-400"
            >
              <ul className="space-y-2 text-gray-400 list-disc list-inside">
                <li>Price sweeps above the Asian session high.</li>
                <li>A Change in State of Delivery (CISD) confirms the reversal (price closes below a prior bullish FVG).</li>
                <li>Enter SELL on a retest of the inverted bullish FVG or a newly created bearish FVG.</li>
                <li>Stop Loss is placed above the high of the entry FVG.</li>
                <li>Take Profit targets the Previous Day's Low or a set R:R.</li>
              </ul>
            </StrategyCard>

            <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-700 shadow-lg">
              <h3 className="text-xl font-semibold text-cyan-400 mb-4">Trade Parameters</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="lotSize" className="block text-sm font-medium text-gray-400 mb-1">Lot Size</label>
                  <input
                    type="number"
                    id="lotSize"
                    name="lotSize"
                    value={inputs.lotSize}
                    onChange={handleInputChange}
                    className="w-full bg-gray-900 border border-gray-600 rounded-md px-3 py-2 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    step="0.01"
                    min="0.01"
                    aria-label="Lot Size"
                  />
                </div>
                 <div className="md:col-span-2">
                  <label htmlFor="takeProfitOption" className="block text-sm font-medium text-gray-400 mb-1">Take Profit Target</label>
                  <select
                    id="takeProfitOption"
                    name="takeProfitOption"
                    value={inputs.takeProfitOption}
                    onChange={handleSelectChange}
                    className="w-full bg-gray-900 border border-gray-600 rounded-md px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    aria-label="Take Profit Target"
                  >
                    <option value="PDH/PDL">Previous Day High/Low</option>
                    <option value="RR_1_1">1:1 Risk/Reward</option>
                    <option value="RR_1_1_5">1:1.5 Risk/Reward</option>
                    <option value="RR_1_2">1:2 Risk/Reward</option>
                    <option value="RR_1_3">1:3 Risk/Reward</option>
                  </select>
                </div>
              </div>
            </div>
            
            <button
              onClick={handleGenerateCode}
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-3 bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-4 px-6 rounded-lg transition-all duration-300 ease-in-out disabled:bg-gray-600 disabled:cursor-not-allowed transform hover:scale-105 shadow-lg shadow-cyan-500/20"
            >
              <SparklesIcon />
              {isLoading ? 'Generating Code...' : 'Generate MQL5 Expert Advisor'}
            </button>
          </div>

          {/* Right Column: Code Display */}
          <div className="lg:sticky top-8 self-start">
            <CodeDisplay code={mql5Code} isLoading={isLoading} error={error} />
          </div>
        </div>
      </main>
      <footer className="text-center p-4 text-gray-600 text-sm mt-8">
        <p>Generated by Gemini. Code is for educational purposes only. Always backtest before use.</p>
      </footer>
    </div>
  );
};

export default App;
